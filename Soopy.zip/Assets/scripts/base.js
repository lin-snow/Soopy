document.addEventListener('DOMContentLoaded', function() {
    console.log('base.js loaded');
});

document.addEventListener('DOMContentLoaded', function() {
    const funbutton = document.getElementById('fun');
    funbutton.addEventListener('click', function() {
        const links = document.getElementById('links');
        const linksTitle = document.getElementById('linksTitle');
        const projects = document.getElementById('projects');
        const projectsTitle = document.getElementById('projectsTitle');
        const resume = document.getElementById('resume');

        links.classList.toggle('hidden');
        linksTitle.classList.toggle('hidden');
        projects.classList.toggle('hidden');
        projectsTitle.classList.toggle('hidden');
        resume.classList.toggle('hidden');
    })
});